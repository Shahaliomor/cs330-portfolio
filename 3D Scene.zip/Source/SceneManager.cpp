﻿///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ================
// This file contains the implementation of the `SceneManager` class, which is 
// responsible for managing the preparation and rendering of 3D scenes. It 
// handles textures, materials, lighting configurations, and object rendering.
//
// AUTHOR: Brian Battersby
// INSTITUTION: Southern New Hampshire University (SNHU)
// COURSE: CS-330 Computational Graphics and Visualization
//
// INITIAL VERSION: November 1, 2023
// LAST REVISED: December 1, 2024
//
// RESPONSIBILITIES:
// - Load, bind, and manage textures in OpenGL.
// - Define materials and lighting properties for 3D objects.
// - Manage transformations and shader configurations.
// - Render complex 3D scenes using basic meshes.
//
// NOTE: This implementation leverages external libraries like `stb_image` for 
// texture loading and GLM for matrix and vector operations.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/transform.hpp>
#include "ViewManager.h"

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.size() == 0)
    {
        return(false);
    }

    int index = 0;
    bool bFound = false;
    while ((index < m_objectMaterials.size()) && (bFound == false))
    {
        if (m_objectMaterials[index].tag.compare(tag) == 0)
        {
            bFound = true;
            material.diffuseColor = m_objectMaterials[index].diffuseColor;
            material.specularColor = m_objectMaterials[index].specularColor;
            material.shininess = m_objectMaterials[index].shininess;
        }
        else
        {
            index++;
        }
    }

    return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
    std::string materialTag)
{
    if (m_objectMaterials.size() > 0)
    {
        OBJECT_MATERIAL material;
        bool bReturn = false;

        // find the defined material that matches the tag
        bReturn = FindMaterial(materialTag, material);
        if (bReturn == true)
        {
            // pass the material properties into the shader
            m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
            m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
            m_pShaderManager->setFloatValue("material.shininess", material.shininess);
        }
    }
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

 /***********************************************************
  *  DefineObjectMaterials()
  *
  *  This method is used for configuring the various material
  *  settings for all of the objects within the 3D scene.
  ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
    /*** STUDENTS - add the code BELOW for defining object materials. ***/
    /*** There is no limit to the number of object materials that can ***/
    /*** be defined. Refer to the code in the OpenGL Sample for help  ***/


    OBJECT_MATERIAL desk;
    desk.tag = "desk";
    desk.diffuseColor = glm::vec3(0.45f, 0.5f, 0.5f);
    desk.specularColor = glm::vec3(0.3f);
    desk.shininess = 8.0f;
    m_objectMaterials.push_back(desk);

    OBJECT_MATERIAL file;
    file.tag = "file";
    file.diffuseColor = glm::vec3(0.1f);
    file.specularColor = glm::vec3(0.2f);
    file.shininess = 4.0f;
    m_objectMaterials.push_back(file);

    OBJECT_MATERIAL silverrim;
    silverrim.tag = "silverrim";
    silverrim.diffuseColor = glm::vec3(0.8f);
    silverrim.specularColor = glm::vec3(1.0f);
    silverrim.shininess = 96.0f;
    m_objectMaterials.push_back(silverrim);

    OBJECT_MATERIAL innerhole;
    innerhole.tag = "innerhole";
    innerhole.diffuseColor = glm::vec3(0.2f, 0.3f, 0.4f);
    innerhole.specularColor = glm::vec3(0.3f);
    innerhole.shininess = 12.0f;
    m_objectMaterials.push_back(innerhole);

    OBJECT_MATERIAL pencil;
    pencil.tag = "pencil";
    pencil.diffuseColor = glm::vec3(0.85f, 0.6f, 0.1f);
    pencil.specularColor = glm::vec3(0.2f);
    pencil.shininess = 8.0f;
    m_objectMaterials.push_back(pencil);

    OBJECT_MATERIAL graphite;
    graphite.tag = "graphite";
    graphite.diffuseColor = glm::vec3(0.1f);
    graphite.specularColor = glm::vec3(0.1f);
    graphite.shininess = 4.0f;
    m_objectMaterials.push_back(graphite);

    OBJECT_MATERIAL plate;
    plate.tag = "plate";
    plate.diffuseColor = glm::vec3(0.9f);
    plate.specularColor = glm::vec3(0.6f);
    plate.shininess = 32.0f;
    m_objectMaterials.push_back(plate);

    OBJECT_MATERIAL plateinner;
    plateinner.tag = "plateinner";
    plateinner.diffuseColor = glm::vec3(0.561f, 0.667f, 0.698f);
    plateinner.specularColor = glm::vec3(0.4f);
    plateinner.shininess = 12.0f;
    m_objectMaterials.push_back(plateinner);

    OBJECT_MATERIAL cup;
    cup.tag = "cup";
    cup.diffuseColor = glm::vec3(1.0f);
    cup.specularColor = glm::vec3(1.0f);
    cup.shininess = 128.0f;
    m_objectMaterials.push_back(cup);

    OBJECT_MATERIAL handleinner;
    handleinner.tag = "handleinner";
    handleinner.diffuseColor = glm::vec3(0.1f);
    handleinner.specularColor = glm::vec3(0.2f);
    handleinner.shininess = 8.0f;
    m_objectMaterials.push_back(handleinner);

    OBJECT_MATERIAL paper;
    paper.tag = "paper";
    paper.diffuseColor = glm::vec3(0.9f);
    paper.specularColor = glm::vec3(0.1f);
    paper.shininess = 2.0f;
    m_objectMaterials.push_back(paper);

    OBJECT_MATERIAL pen;
    pen.tag = "pen";
    pen.diffuseColor = glm::vec3(0.05f);
    pen.specularColor = glm::vec3(0.2f);
    pen.shininess = 12.0f;
    m_objectMaterials.push_back(pen);

    OBJECT_MATERIAL pentip;
    pentip.tag = "pentip";
    pentip.diffuseColor = glm::vec3(0.8f);
    pentip.specularColor = glm::vec3(1.0f);
    pentip.shininess = 64.0f;
    m_objectMaterials.push_back(pentip);

    OBJECT_MATERIAL notebook;
    notebook.tag = "notebook";
    notebook.diffuseColor = glm::vec3(0.35f, 0.35f, 0.35f);
    notebook.specularColor = glm::vec3(0.75f);
    notebook.shininess = 32.0f;
    m_objectMaterials.push_back(notebook);

    OBJECT_MATERIAL notebookside;
    notebookside.tag = "notebookside";
    notebookside.diffuseColor = glm::vec3(0.4f);
    notebookside.specularColor = glm::vec3(0.3f);
    notebookside.shininess = 16.0f;
    m_objectMaterials.push_back(notebookside);

    OBJECT_MATERIAL notebookpages;
    notebookpages.tag = "notebookpages";
    notebookpages.diffuseColor = glm::vec3(0.95f);
    notebookpages.specularColor = glm::vec3(0.3f);
    notebookpages.shininess = 16.0f;
    m_objectMaterials.push_back(notebookpages);

    OBJECT_MATERIAL tabletframe;
    tabletframe.tag = "tabletframe";
    tabletframe.diffuseColor = glm::vec3(0.6f);
    tabletframe.specularColor = glm::vec3(0.95f);
    tabletframe.shininess = 96.0f;
    m_objectMaterials.push_back(tabletframe);

    OBJECT_MATERIAL tablet;
    tablet.tag = "tablet";
    tablet.diffuseColor = glm::vec3(0.3f);
    tablet.specularColor = glm::vec3(0.6f);
    tablet.shininess = 64.0f;
    m_objectMaterials.push_back(tablet);




}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
    // this line of code is NEEDED for telling the shaders to render 
    // the 3D scene with custom lighting, if no light sources have
    // been added then the display window will be black - to use the 
    // default OpenGL lighting then comment out the following line
    //m_pShaderManager->setBoolValue(g_UseLightingName, true);

    /*** STUDENTS - add the code BELOW for setting up light sources ***/
    /*** Up to four light sources can be defined. Refer to the code ***/
    /*** in the OpenGL Sample for help                              ***/


    // Enable lighting
    m_pShaderManager->setBoolValue("bUseLighting", true);

    // 1. Directional Light – Bright Diffused Sunlight from Top-Left
    m_pShaderManager->setBoolValue("directionalLight.bActive", true);
    m_pShaderManager->setVec3Value("directionalLight.direction", -0.4f, -1.0f, -0.3f); 
    m_pShaderManager->setVec3Value("directionalLight.ambient", 0.35f, 0.35f, 0.35f);  
    m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.75f, 0.75f, 0.75f);  
    m_pShaderManager->setVec3Value("directionalLight.specular", 0.45f, 0.45f, 0.45f);


    // 2. Point Light – Fill from Front-Left (Warmer Fill)
    m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
    m_pShaderManager->setVec3Value("pointLights[0].position", -2.0f, 0.8f, 2.0f);
    m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.08f, 0.08f, 0.08f);
    m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.35f, 0.35f, 0.35f);
    m_pShaderManager->setVec3Value("pointLights[0].specular", 0.5f, 0.5f, 0.5f);
    m_pShaderManager->setFloatValue("pointLights[0].constant", 1.0f);
    m_pShaderManager->setFloatValue("pointLights[0].linear", 0.06f);
    m_pShaderManager->setFloatValue("pointLights[0].quadratic", 0.012f);

    // 3. Spot Light – Sharper Beam from Right
    m_pShaderManager->setBoolValue("spotLight.bActive", true);
    m_pShaderManager->setVec3Value("spotLight.position", 2.8f, 2.5f, 2.2f);
    m_pShaderManager->setVec3Value("spotLight.direction", -2.6f, -2.2f, -2.0f);
    m_pShaderManager->setFloatValue("spotLight.cutOff", glm::cos(glm::radians(25.0f)));
    m_pShaderManager->setFloatValue("spotLight.outerCutOff", glm::cos(glm::radians(42.0f)));
    m_pShaderManager->setVec3Value("spotLight.ambient", 0.04f, 0.04f, 0.04f); 
    m_pShaderManager->setVec3Value("spotLight.diffuse", 1.4f, 1.4f, 1.4f);    
    m_pShaderManager->setVec3Value("spotLight.specular", 1.0f, 1.0f, 1.0f);   
    m_pShaderManager->setFloatValue("spotLight.constant", 1.0f);
    m_pShaderManager->setFloatValue("spotLight.linear", 0.04f);
    m_pShaderManager->setFloatValue("spotLight.quadratic", 0.009f);


}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
    // Load the textures
    CreateGLTexture("textures/desk.jpg", "desk");                       // Desk base
    CreateGLTexture("textures/coffeesurface.jpg", "coffee");            // Coffee surface
    CreateGLTexture("textures/notebookside.jpg", "notebookside");       // Notebook side
    CreateGLTexture("textures/notebook.jpg", "notebook");               // Notebook
    CreateGLTexture("textures/notebook.jpg", "notebook");               // Notebook
    CreateGLTexture("textures/paper.jpg", "paper");                     // paper surface
    CreateGLTexture("textures/pencil.jpg", "pencil");                   // pencil
    CreateGLTexture("textures/tabletscreen.jpg", "tablet");             // Tablet screen
	CreateGLTexture("textures/silvermetal.jpg", "silvermetal");         // Tablet body  
	CreateGLTexture("textures/stackedpaper.jpg", "stackedpaper");       // paper stack


    // Bind textures to OpenGL texture slots
    BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{

    // define the materials for objects in the scene
    DefineObjectMaterials();
    // add and define the light sources for the scene
    SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

    // Load box, cylinder, and plane meshes once.
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadConeMesh();

    // Load all textures for 3d scene
    LoadSceneTextures();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/

void SceneManager::RenderScene()
{
    glm::vec3 scaleXYZ;
    glm::vec3 positionXYZ;
    float XrotationDegrees = 0.0f, YrotationDegrees = 0.0f, ZrotationDegrees = 0.0f;

    // ====================
    // 1) Desk Surface
    // --------------------
    // Renders the flat desk surface where all other objects rest.
    // Utilizes a textured box to simulate a wooden or smooth tabletop.
    // - Mesh Type: Box
    // - Texture Tag: "desk" (must be loaded with CreateGLTexture)
    // - Scale: (width = 12.0, height = 0.1, depth = 8.0)
    // - Position: Y = -0.55 places it below the object baseline
    // ====================

    // Set the size of the desk surface
    scaleXYZ = glm::vec3(12.0f, 0.1f, 8.0f);  // Width (X), Thickness (Y), Depth (Z)

    // Set the position so the top of the desk aligns with Y=0
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);  // Centered in X and Z, lowered in Y

    // Apply scale and position transformations (no rotation)
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

    // Bind the "desk" texture to simulate a realistic surface
    SetShaderTexture("desk");  // Must match the tag used in CreateGLTexture()
    SetShaderMaterial("desk");

    // Optional: Modify texture tiling if needed (1.0f = default mapping)
    SetTextureUVScale(1.0f, 1.0f);  // Increase to tile, decrease to stretch

    // Render the desk as a box mesh with the above properties
    m_basicMeshes->DrawBoxMesh();


    // ====================
    // 2) File Stack (3 files with silver-rimmed holes)
    // ====================
        {
            float xStart = -2.5f;                // Starting X position for the first file
            float fileHeight = 1.5f;             // Height of each file

            for (int i = 0; i < 3; ++i)
            {
                float fileShade = (i == 1 ? 0.30f : 0.10f);  // Middle file slightly brighter

                // --------------------
                // File Body (Box)
                // --------------------
                scaleXYZ = glm::vec3(0.40f, fileHeight, 0.80f);
                positionXYZ = glm::vec3(xStart + i * 0.40f, fileHeight / 2.0f, -2.0f);
                SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
                SetShaderColor(fileShade, fileShade, fileShade, 1.0f);
                SetShaderMaterial("file");
                m_basicMeshes->DrawBoxMesh();

                // --------------------
                // Silver Rim (Front Ring)
                // --------------------
                scaleXYZ = glm::vec3(0.10f, 0.01f, 0.10f);  // Thin flat ring
                positionXYZ = glm::vec3(xStart + i * 0.40f, 0.3f, -1.59f); 
                SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
                SetShaderColor(0.80f, 0.80f, 0.85f, 1.0f);
                SetShaderMaterial("silverrim");
                m_basicMeshes->DrawCylinderMesh();

                // --------------------
                // Inner Hole (Cylinder)
                // --------------------
                scaleXYZ = glm::vec3(0.06f, 0.004f, 0.06f);
                positionXYZ = glm::vec3(xStart + i * 0.40f, 0.3f, -1.58f);  // Slight Z-offset for visibility
                SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
                SetShaderColor(0.25f, 0.45f, 0.5f, 1.0f);
                SetShaderMaterial("innerhole");
                m_basicMeshes->DrawCylinderMesh();
            }
        }


    // ====================
    // 3) Transparent Cup with Two Pencils
    // ====================
    {
        // ====================
        // Pencils Setup
        // ====================
        glm::vec3 pencilPositions[2] = {
            glm::vec3(-1.26f, 0.10f, -0.51f),
            glm::vec3(-1.23f, 0.10f, -0.48f)
        };
        float pencilRotations[2] = { -12.0f, 12.0f };

        float pencilHeight = 0.50f;
        float tipHeight = 0.05f;
        int   tipSegments = 3;
        float tipSpacingOffset = -0.024f;
        float tipBaseRadius = 0.028f;
        float tipTopRadius = 0.018f;

        for (int i = 0; i < 2; ++i)
        {
            // Pencil Body
            scaleXYZ = glm::vec3(0.03f, pencilHeight, 0.03f);
            positionXYZ = pencilPositions[i];
            ZrotationDegrees = pencilRotations[i];
            SetTransformations(scaleXYZ, 0.0f, 0.0f, ZrotationDegrees, positionXYZ);
            SetShaderTexture("pencil");
            SetShaderMaterial("pencil");
            m_basicMeshes->DrawCylinderMesh();

            // Pencil Tip Segments
            float totalTipHeight = tipSegments * (tipHeight + tipSpacingOffset);
            glm::vec3 localUp(0.0f, pencilHeight, 0.0f);
            glm::mat4 rotZ = glm::rotate(glm::mat4(1.0f), glm::radians(pencilRotations[i]), glm::vec3(0.0f, 0.0f, 1.0f));
            glm::vec3 tipOriginOffset = glm::vec3(rotZ * glm::vec4(localUp, 0.0f));
            glm::vec3 tipBasePos = pencilPositions[i] + tipOriginOffset - glm::vec3(0.0f, 0.02f, 0.0f);

            for (int j = 0; j < tipSegments; ++j)
            {
                float t = static_cast<float>(j) / (tipSegments - 1);
                float radius = tipBaseRadius - t * (tipBaseRadius - tipTopRadius);
                float centerOffset = j * (tipHeight + tipSpacingOffset) + tipHeight / 2.0f;
                glm::vec3 yOffset = glm::vec3(rotZ * glm::vec4(0.0f, centerOffset, 0.0f, 0.0f));
                glm::vec3 segmentPos = tipBasePos + yOffset;

                scaleXYZ = glm::vec3(radius, tipHeight / 2.0f, radius);
                positionXYZ = segmentPos;
                ZrotationDegrees = pencilRotations[i];
                SetTransformations(scaleXYZ, 0.0f, 0.0f, ZrotationDegrees, positionXYZ);
                SetShaderColor(0.95f, 0.85f, 0.60f, 1.0f);
                m_basicMeshes->DrawCylinderMesh();
            }

            // Graphite Cone Tip
            glm::vec3 coneYOffset = glm::vec3(rotZ * glm::vec4(0.0f, totalTipHeight + 0.02f, 0.0f, 0.0f));
            glm::vec3 conePos = tipBasePos + coneYOffset;
            scaleXYZ = glm::vec3(0.015f, 0.04f, 0.015f);
            positionXYZ = conePos;
            ZrotationDegrees = pencilRotations[i];
            SetTransformations(scaleXYZ, 0.0f, 0.0f, ZrotationDegrees, positionXYZ);
            SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f);
            SetShaderMaterial("graphite");
            m_basicMeshes->DrawConeMesh();
        }

        // ====================
        // Plate Under Cup
        // ====================
        scaleXYZ = glm::vec3(0.24f, 0.015f, 0.23f);
        positionXYZ = glm::vec3(-1.25f, 0.09f, -0.5f);
        SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
        SetShaderColor(0.85f, 0.85f, 0.85f, 0.3f);
        SetShaderMaterial("plate");
        m_basicMeshes->DrawCylinderMesh();

        // Inner Plate Surface
        scaleXYZ = glm::vec3(0.19f, 0.005f, 0.19f);
        positionXYZ.y += 0.011f;
        SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
        SetShaderColor(0.561f, 0.667f, 0.698f, 1.0f);
        SetShaderMaterial("plateinner");
        m_basicMeshes->DrawCylinderMesh();

        // ====================
        // Transparent Cup (Stacked Layers)
        // ====================
        int segments = 5;
        float segmentHeight = 0.1f;
        float baseY = -0.02f + 0.10f; // Shift total +0.10f
        float baseRadius = 0.14f;
        float topRadius = 0.20f;
        float manualYOffset = -0.044f;

        for (int i = 0; i < segments; ++i)
        {
            float t = static_cast<float>(i) / (segments - 1);
            float radius = baseRadius + t * (topRadius - baseRadius);
            float centerY = baseY + i * (segmentHeight + manualYOffset) + segmentHeight / 2.0f;

            scaleXYZ = glm::vec3(radius, segmentHeight / 2.0f, radius);
            positionXYZ = glm::vec3(-1.25f, centerY, -0.5f);
            SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
            SetShaderColor(0.95f, 0.95f, 0.95f, 0.35f);
            SetShaderMaterial("plate"); // Reuse transparent material
            m_basicMeshes->DrawCylinderMesh();
        }
    }


    // ====================
    // 4) Coffee Cup
    // ====================
        {
            // --------------------
            // Lower Cup Body
            // --------------------
            scaleXYZ = glm::vec3(0.15f, 0.16f, 0.15f);
            positionXYZ = glm::vec3(-0.8f, 0.16f, -0.05f);         
            SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
            SetShaderColor(1.00f, 1.00f, 1.00f, 1.0f);
            SetShaderMaterial("cup");
            m_basicMeshes->DrawCylinderMesh();

            // --------------------
            // Flared Upper Rim (Top Ring)
            // --------------------
            glm::vec3 rimCenter = glm::vec3(-0.8f, 0.32f, -0.05f);   
            scaleXYZ = glm::vec3(0.18f, 0.05f, 0.18f);
            positionXYZ = rimCenter;
            SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
            SetShaderColor(1.00f, 1.00f, 1.00f, 1.0f);
            SetShaderMaterial("cup");
            m_basicMeshes->DrawCylinderMesh();

            // --------------------
            // Coffee Surface (Inside Rim)
            // --------------------
            scaleXYZ = glm::vec3(0.155f, 0.051f, 0.155f);
            positionXYZ = rimCenter; // Same as rim
            SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
            SetShaderTexture("coffee");
            m_basicMeshes->DrawCylinderMesh();

            // --------------------
            // Cup Handle (Outer Cylinder)
            // --------------------
            scaleXYZ = glm::vec3(0.05f, 0.10f, 0.05f);
            positionXYZ = glm::vec3(-0.65f, 0.26f, -0.05f);         
            SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
            SetShaderColor(1.00f, 1.00f, 1.00f, 1.0f);
            SetShaderMaterial("cup");
            m_basicMeshes->DrawCylinderMesh();

            // --------------------
            // Handle Hollow (Inner Tube)
            // --------------------
            scaleXYZ = glm::vec3(0.025f, 0.10f, 0.025f);
            positionXYZ = glm::vec3(-0.65f, 0.26f, -0.045f);        
            SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
            SetShaderColor(0.08f, 0.15f, 0.18f, 1.0f);
            SetShaderMaterial("handleinner");
            m_basicMeshes->DrawCylinderMesh();
        }


    // ====================
    // 5) Paper with Pen and Stacked Sheets
    // ====================
        {
            float paperYRot = 25.0f; // Diagonal rotation around Y-axis

            // --------------------
            // Paper Shadow/Depth Layer
            // --------------------
            scaleXYZ = glm::vec3(1.2f, 0.01f, 1.6f);                      
            positionXYZ = glm::vec3(-3.6f, 0.05f, 0.01f);                 
            SetTransformations(scaleXYZ, 0.0f, paperYRot, 0.0f, positionXYZ);
            SetShaderColor(0.07f, 0.07f, 0.07f, 1.0f);                  
            SetShaderMaterial("paper");

            m_basicMeshes->DrawBoxMesh();

            // --------------------
            // Paper Stack Layers
            // --------------------
            int numSheets = 4;
            float sheetOffset = 0.025f;

            for (int i = 0; i < numSheets; ++i)
            {
                float offset = i * sheetOffset;

                scaleXYZ = glm::vec3(1.16f - offset * 0.5f, 0.01f, 1.55f - offset);
                positionXYZ = glm::vec3(-3.6f - offset * 0.5f, 0.06f + i * 0.003f, 0.01f - offset * 0.6f);
                SetTransformations(scaleXYZ, 0.0f, paperYRot, 0.0f, positionXYZ);
                SetShaderTexture("paper");                                        
                SetShaderMaterial("paper");
                m_basicMeshes->DrawBoxMesh();
            }

            // --------------------
            // Pen Body
            // --------------------
            glm::vec3 penPosition = glm::vec3(-3.5f, 0.08f, 0.9f);
            float penXRot = 90.0f;
            float penYRot = 110.0f + paperYRot;  // Add paper rotation to pen's Y
            float penZRot = 0.0f;

            scaleXYZ = glm::vec3(0.03f, 0.72f, 0.03f);                         // Pen size
            SetTransformations(scaleXYZ, penXRot, penYRot, penZRot, penPosition);
            SetShaderColor(0.05f, 0.05f, 0.05f, 1.0f);                         // Matte black pen
            SetShaderMaterial("pen");
            m_basicMeshes->DrawCylinderMesh();

            // --------------------
            // Pen Silver Tip
            // --------------------
            glm::vec3 tipBaseOffset(0.0f, 0.72f, 0.0f);
            glm::mat4 rotMatrix = glm::rotate(glm::mat4(1.0f), glm::radians(penYRot), glm::vec3(0.0f, 1.0f, 0.0f));
            rotMatrix = glm::rotate(rotMatrix, glm::radians(penXRot), glm::vec3(1.0f, 0.0f, 0.0f));
            glm::vec3 tipBasePos = penPosition + glm::vec3(rotMatrix * glm::vec4(tipBaseOffset, 0.0f));

            int tipSegments = 3;
            float tipHeight = 0.02f;
            float tipSpacing = -0.0023f;
            float tipBaseRadius = 0.026f;
            float tipTopRadius = 0.015f;

            for (int j = 0; j < tipSegments; ++j)
            {
                float t = static_cast<float>(j) / (tipSegments - 1);
                float radius = tipBaseRadius - t * (tipBaseRadius - tipTopRadius);
                float yOffset = j * (tipHeight + tipSpacing) + tipHeight / 2.0f;

                glm::vec3 segmentOffset = glm::vec3(rotMatrix * glm::vec4(0.0f, yOffset, 0.0f, 0.0f));
                glm::vec3 segmentPos = tipBasePos + segmentOffset;

                scaleXYZ = glm::vec3(radius, tipHeight / 2.0f, radius);
                SetTransformations(scaleXYZ, penXRot, penYRot, penZRot, segmentPos);
                SetShaderColor(0.80f, 0.80f, 0.80f, 1.0f);                      // Silver taper
                SetShaderMaterial("pentip");
                m_basicMeshes->DrawCylinderMesh();
            }

            // --------------------
            // Graphite Tip
            // --------------------
            glm::vec3 coneOffset = glm::vec3(rotMatrix * glm::vec4(0.0f, tipSegments * (tipHeight + tipSpacing) + 0.01f, 0.0f, 0.0f));
            glm::vec3 conePos = tipBasePos + coneOffset;

            scaleXYZ = glm::vec3(0.01f, 0.03f, 0.01f);                         // Cone tip
            SetTransformations(scaleXYZ, penXRot, penYRot, penZRot, conePos);
            SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);                         // Graphite
            SetShaderMaterial("graphite");
            m_basicMeshes->DrawConeMesh();
        }

    // ====================
    // 6) Notebook
    // ====================
        {
            // --------------------
            // Notebook Pages (White Sheet Block)
            // --------------------
            glm::vec3 scaleXYZ_pages = glm::vec3(1.0f, 0.15f, 1.22f);
            glm::vec3 positionXYZ_pages = glm::vec3(-1.99f, 0.125f, 0.40f);        // Sits on desk
            SetTransformations(scaleXYZ_pages, 0.0f, 180.0f, 0.0f, positionXYZ_pages);
            SetShaderColor(0.90f, 0.90f, 0.90f, 1.0f);
            SetShaderTexture("stackedpaper");
            SetShaderMaterial("notebookpages");
            m_basicMeshes->DrawBoxMesh();

            // --------------------
            // Notebook Cover (Textured)
            // --------------------
            glm::vec3 scaleXYZ_cover = glm::vec3(1.00f, 0.15f, 1.20f);
            glm::vec3 positionXYZ_cover = glm::vec3(-2.00f, 0.13f, 0.40f);
            SetTransformations(scaleXYZ_cover, 0.0f, 180.0f, 0.0f, positionXYZ_cover);
            SetShaderTexture("notebook");
            SetShaderMaterial("notebook");
            m_basicMeshes->DrawBoxMesh();

            // --------------------
            // Left Binding Strip
            // --------------------
            glm::vec3 scaleXYZ_binding = glm::vec3(0.03f, 0.16f, 1.21f);
            glm::vec3 positionXYZ_binding = glm::vec3(-2.5f, 0.125f, 0.40f);
            SetTransformations(scaleXYZ_binding, 0.0f, 180.0f, 0.0f, positionXYZ_binding);
            SetShaderTexture("notebookside");
            SetShaderMaterial("notebookside");
            m_basicMeshes->DrawBoxMesh();
        }


    // ====================
    // 7) Separate Pen (To the Right of Notebook) with Cap and Clip
    // ====================
        {
            // --------------------
            // Pen Body (Matte Black Cylinder)
            // --------------------
            glm::vec3 penPos = glm::vec3(-1.2f, 0.10f, 0.50f); // Raised to sit on desk
            float penLength = 0.85f;
            float penRadius = 0.05f;

            scaleXYZ = glm::vec3(penRadius, penLength, penRadius); // Radius = XZ, Length = Y axis (rotated)
            SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, penPos); // Rotate 90° around X to lay flat
            SetShaderColor(0.05f, 0.05f, 0.05f, 1.0f); // Matte black finish
            SetShaderMaterial("pen");

            m_basicMeshes->DrawCylinderMesh();

            // --------------------
            // Tapered Pen Tip (Stacked Cylinders)
            // --------------------
            glm::vec3 tipBase = glm::vec3(penPos.x, penPos.y, penPos.z + penLength + 0.01f); // Just past body
            int tipSegments = 4;
            float tipHeight = 0.015f;
            float tipSpacing = -0.0023f;
            float tipBaseRadius = 0.045f;
            float tipTopRadius = 0.025f;

            for (int j = 0; j < tipSegments; ++j)
            {
                float t = static_cast<float>(j) / (tipSegments - 1);
                float radius = tipBaseRadius - t * (tipBaseRadius - tipTopRadius);
                float yOffset = j * (tipHeight + tipSpacing) + tipHeight / 2.0f;

                glm::vec3 segmentPos = glm::vec3(tipBase.x, tipBase.y, tipBase.z + yOffset);
                scaleXYZ = glm::vec3(radius, tipHeight / 2.0f, radius);
                SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, segmentPos);
                SetShaderColor(0.80f, 0.80f, 0.80f, 1.0f); // Metallic silver tip
                SetShaderMaterial("pentip");

                m_basicMeshes->DrawCylinderMesh();
            }

            // --------------------
            // Graphite Cone Tip (Final Point)
            // --------------------
            glm::vec3 conePos = glm::vec3(
                tipBase.x,
                tipBase.y,
                tipBase.z + tipSegments * (tipHeight + tipSpacing) + 0.015f
            );
            scaleXYZ = glm::vec3(0.01f, 0.025f, 0.01f); // Narrow tip cone
            SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, conePos);
            SetShaderColor(0.1f, 0.1f, 0.1f, 1.0f); // Graphite (dark gray)
            SetShaderMaterial("graphite");

            m_basicMeshes->DrawConeMesh();

            // --------------------
            // Pen Cap (Light Silver Cylinder)
            // --------------------
            glm::vec3 capPos = glm::vec3(penPos.x, penPos.y, penPos.z - 0.06f); // Behind body
            scaleXYZ = glm::vec3(0.045f, 0.08f, 0.045f);
            SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, capPos);
            SetShaderColor(0.85f, 0.85f, 0.85f, 1.0f); // Metallic cap
            SetShaderMaterial("pentip");

            m_basicMeshes->DrawCylinderMesh();
        }


    // ====================
    // 8) Tablet
    // ====================
        {
            // --------------------
            // Tablet Body (Outer Frame)
            // --------------------
            scaleXYZ = glm::vec3(1.60f, 0.06f, 1.00f); 
            positionXYZ = glm::vec3(0.28f, 0.05f, 0.5f);
            SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
            SetShaderTexture("silvermetal");
            SetShaderMaterial("tabletframe");
            m_basicMeshes->DrawBoxMesh();

            // --------------------
            // Tablet Screen (Top Surface)
            // --------------------
            scaleXYZ = glm::vec3(1.36f, 0.01f, 0.76f);
            positionXYZ = glm::vec3(0.28f, 0.08f, 0.5f); 
            SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
            SetShaderTexture("tablet");
            SetShaderMaterial("tablet");
            m_basicMeshes->DrawBoxMesh();

        }

}
